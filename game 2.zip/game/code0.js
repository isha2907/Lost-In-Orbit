gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDRocketObjects1= [];
gdjs.Untitled_32sceneCode.GDRocketObjects2= [];
gdjs.Untitled_32sceneCode.GDStartButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDStartButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDExplosionObjects1= [];
gdjs.Untitled_32sceneCode.GDExplosionObjects2= [];
gdjs.Untitled_32sceneCode.GDAstronautObjects1= [];
gdjs.Untitled_32sceneCode.GDAstronautObjects2= [];
gdjs.Untitled_32sceneCode.GDPlanetObjects1= [];
gdjs.Untitled_32sceneCode.GDPlanetObjects2= [];
gdjs.Untitled_32sceneCode.GDPlanet2Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet2Objects2= [];
gdjs.Untitled_32sceneCode.GDPlanet3Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet3Objects2= [];
gdjs.Untitled_32sceneCode.GDPlanet4Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet4Objects2= [];
gdjs.Untitled_32sceneCode.GDPlanet5Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet5Objects2= [];
gdjs.Untitled_32sceneCode.GDPlanet7Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet7Objects2= [];
gdjs.Untitled_32sceneCode.GDPlanet6Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet6Objects2= [];
gdjs.Untitled_32sceneCode.GDPlanet8Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet8Objects2= [];
gdjs.Untitled_32sceneCode.GDPlanet9Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet9Objects2= [];
gdjs.Untitled_32sceneCode.GDPlanet10Objects1= [];
gdjs.Untitled_32sceneCode.GDPlanet10Objects2= [];
gdjs.Untitled_32sceneCode.GDEarthObjects1= [];
gdjs.Untitled_32sceneCode.GDEarthObjects2= [];
gdjs.Untitled_32sceneCode.GDAimArrowObjects1= [];
gdjs.Untitled_32sceneCode.GDAimArrowObjects2= [];
gdjs.Untitled_32sceneCode.GDRetryButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDRetryButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDStatusTextObjects1= [];
gdjs.Untitled_32sceneCode.GDStatusTextObjects2= [];
gdjs.Untitled_32sceneCode.GDFadeOverlayObjects1= [];
gdjs.Untitled_32sceneCode.GDFadeOverlayObjects2= [];
gdjs.Untitled_32sceneCode.GDAsteroidObjects1= [];
gdjs.Untitled_32sceneCode.GDAsteroidObjects2= [];
gdjs.Untitled_32sceneCode.GDAsteroid2Objects1= [];
gdjs.Untitled_32sceneCode.GDAsteroid2Objects2= [];
gdjs.Untitled_32sceneCode.GDAsteroid3Objects1= [];
gdjs.Untitled_32sceneCode.GDAsteroid3Objects2= [];
gdjs.Untitled_32sceneCode.GDAsteroid4Objects1= [];
gdjs.Untitled_32sceneCode.GDAsteroid4Objects2= [];
gdjs.Untitled_32sceneCode.GDAsteroid5Objects1= [];
gdjs.Untitled_32sceneCode.GDAsteroid5Objects2= [];
gdjs.Untitled_32sceneCode.GDStarObjects1= [];
gdjs.Untitled_32sceneCode.GDStarObjects2= [];
gdjs.Untitled_32sceneCode.GDStar2Objects1= [];
gdjs.Untitled_32sceneCode.GDStar2Objects2= [];
gdjs.Untitled_32sceneCode.GDStar3Objects1= [];
gdjs.Untitled_32sceneCode.GDStar3Objects2= [];
gdjs.Untitled_32sceneCode.GDStar4Objects1= [];
gdjs.Untitled_32sceneCode.GDStar4Objects2= [];
gdjs.Untitled_32sceneCode.GDStar5Objects1= [];
gdjs.Untitled_32sceneCode.GDStar5Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];


gdjs.Untitled_32sceneCode.userFunc0x939de0 = function GDJSInlineCode(runtimeScene) {
"use strict";
runtimeScene.setBackgroundColor(100,100,240);

/*
 BOUNCE BACK: LOST IN SPACE
 VERSION 24

 WHAT'S NEW:
 - Gameplay camera zooms in closer.
 - Planets appear larger on screen.
 - Sprite sizes stay as set in the
   GDevelop Scene Editor.
 - No setWidth, setHeight or setScale.
 - Five columns, three objects each.
 - Random correct objects.
 - Three difficulty levels.
 - Rocket explosion and astronaut.
 - Drag-back slingshot controls.
 - Orbiting and Earth destination.

 REQUIRED SPRITES:
 Rocket
 Explosion
 Astronaut
 AimArrow
 Earth
 FadeOverlay

 REQUIRED TEXT OBJECTS:
 StartButton
 RetryButton
 StatusText

 SPACE OBJECTS:
 Planet to Planet10
 Star to Star5
 Asteroid to Asteroid5

 LAYERS:
 Base layer: ""
 UI
 Transition

 Place one instance of each object
 in the scene.

 IMPORTANT:
 Disable older gameplay JS events.
*/

// =====================================
// 1. GAME SETUP
// =====================================

const scene = runtimeScene;
const game = scene.getGame();
const input = game.getInputManager();

const dt = Math.min(
  scene.getElapsedTime() / 1000,
  0.05
);

const W = game.getGameResolutionWidth();
const H = game.getGameResolutionHeight();

function find(name) {
  const list = scene.getObjects(name);
  return list.length ? list[0] : null;
}

const rocket = find("Rocket");
const explosion = find("Explosion");
const hero = find("Astronaut");
const arrow = find("AimArrow");
const earth = find("Earth");
const fade = find("FadeOverlay");

const start = find("StartButton");
const retry = find("RetryButton");
const status = find("StatusText");

const base = scene.getLayer("");
const ui = scene.getLayer("UI");
const transition = scene.getLayer("Transition");

const names = [
  "Planet","Planet2","Planet3",
  "Planet4","Planet5","Planet6",
  "Planet7","Planet8","Planet9",
  "Planet10",
  "Star","Star2","Star3",
  "Star4","Star5",
  "Asteroid","Asteroid2",
  "Asteroid3","Asteroid4",
  "Asteroid5"
];

const bodies = names.map(find);

const levels = [
  {name:"SPACE ROOKIE",seconds:2},
  {name:"COSMIC EXPLORER",seconds:1.2},
  {name:"GALACTIC MASTER",seconds:0.6}
];

// =====================================
// 2. WORLD LAYOUT
// =====================================

// Positions only.
// Sprite dimensions are never changed.

const X = [
  600,1200,1800,2400,3000
];

const Y = [
  300,750,1200
];

const START_X = 120;
const START_Y = 750;

const EARTH_X = 3650;
const EARTH_Y = 750;

const WORLD_Y = 750;

// Show all five columns during memory.
const MEMORY_ZOOM = Math.min(
  1,
  W / 4000,
  H / 1750
);

// UPDATED IN VERSION 24:
// Zoom in closer during gameplay.
// Objects appear larger on screen.

const GAME_ZOOM = Math.min(
  1,
  W / 1400,
  H / 1400
);

// =====================================
// 3. HELPER FUNCTIONS
// =====================================

function show(o,yes) {
  if (o) o.hide(!yes);
}

function say(o,message) {
  if (o) o.setString(message);
}

function clamp(v,a,b) {
  return Math.max(a,Math.min(b,v));
}

function pos(o) {
  if (!o) return {x:0,y:0};

  return {
    x:o.getX()+o.getWidth()/2,
    y:o.getY()+o.getHeight()/2
  };
}

function put(o,x,y) {
  if (!o) return;

  o.setPosition(
    x-o.getWidth()/2,
    y-o.getHeight()/2
  );
}

function distance(a,b) {
  return Math.hypot(
    a.x-b.x,
    a.y-b.y
  );
}

function shuffle(a) {
  for (let i=a.length-1;i>0;i--) {
    const j=Math.floor(
      Math.random()*(i+1)
    );

    [a[i],a[j]]=[a[j],a[i]];
  }

  return a;
}

function changePhase(p) {
  state.phase=p;
  state.time=0;
}

function camera(x,y,z) {
  base.setCameraX(x);
  base.setCameraY(y);
  base.setCameraZoom(z);
}

// =====================================
// 4. GLOW
// =====================================

function glow(o,yes) {
  if (!o) return;

  try {
    o.enableEffect("PlanetGlow",yes);
  } catch(e) {}
}

function clearGlow() {
  bodies.forEach(o=>{
    if (!o) return;

    glow(o,false);
    o.setOpacity(255);
  });
}

function memoryGlow(index,time) {
  bodies.forEach((o,i)=>{
    if (!o) return;

    const active=i===index;

    glow(o,active);

    o.setOpacity(
      active
        ?180+Math.round(
          75*Math.abs(Math.sin(time*9))
        )
        :255
    );
  });
}

// =====================================
// 5. STATE
// =====================================

const variable = scene
  .getVariables()
  .get("BounceBackVersion24");

let state;

try {
  state=JSON.parse(
    variable.getAsString()
  );
} catch(e) {
  state=null;
}

if (!state || state.version!==24) {
  const opening=rocket
    ?pos(rocket)
    :{x:W/2,y:H/2};

  state={
    version:24,
    phase:"menu",
    time:0,

    level:1,
    groups:[],
    column:0,

    orbitIndex:-1,
    orbitAngle:Math.PI,

    dragging:false,
    vx:0,
    vy:0,
    flightTime:0,

    previousDown:false,

    camX:opening.x,
    camY:opening.y,
    camZoom:1,

    openingX:opening.x,
    openingY:opening.y,

    rocketX:rocket?rocket.getX():0,
    rocketY:rocket?rocket.getY():0,

    safeX:START_X,
    safeY:START_Y
  };

  bodies.forEach(o=>show(o,false));

  [
    explosion,hero,arrow,earth,
    fade,retry,status
  ].forEach(o=>show(o,false));

  show(rocket,true);
  show(start,true);

  clearGlow();

  say(start,"START GAME");

  if (start) {
    start.setPosition(
      W/2-110,
      H/2+120
    );
  }

  if (status) {
    status.setPosition(25,25);
  }

  if (retry) {
    retry.setPosition(
      W/2-110,
      H/2+110
    );
  }

  camera(opening.x,opening.y,1);
}

// =====================================
// 6. MOUSE INPUT
// =====================================

const down=input.isMouseButtonPressed(0);

const pressed=
  down&&!state.previousDown;

const released=
  !down&&state.previousDown;

let mouseX=0;
let mouseY=0;

try {
  mouseX=gdjs.evtTools.input.getCursorX(
    scene,"",0
  );

  mouseY=gdjs.evtTools.input.getCursorY(
    scene,"",0
  );
} catch(e) {
  const z=Math.max(
    0.01,
    base.getCameraZoom()
  );

  mouseX=base.getCameraX()+
    (input.getMouseX()-W/2)/z;

  mouseY=base.getCameraY()+
    (input.getMouseY()-H/2)/z;
}

const mouse={x:mouseX,y:mouseY};

state.time+=dt;

// =====================================
// 7. RANDOM GROUPS
// =====================================

function generateGroups() {
  const available=[];

  bodies.forEach((o,i)=>{
    if (o) available.push(i);
  });

  if (available.length<15) {
    return null;
  }

  shuffle(available);

  const groups=[];

  bodies.forEach(o=>{
    show(o,false);
    glow(o,false);
  });

  for (let c=0;c<5;c++) {
    const chosen=available.slice(
      c*3,c*3+3
    );

    const correct=chosen[
      Math.floor(Math.random()*3)
    ];

    for (let r=0;r<3;r++) {
      const o=bodies[chosen[r]];

      // KEEP SCENE EDITOR SIZE.
      put(o,X[c],Y[r]);

      o.setAngle(0);
      o.setOpacity(255);

      show(o,true);
      glow(o,false);
    }

    groups.push({
      items:chosen,
      correct:correct
    });
  }

  return groups;
}

// =====================================
// 8. LEVEL START
// =====================================

function startLevel(level) {
  const groups=generateGroups();

  if (!groups) {
    changePhase("error");

    show(status,true);

    say(
      status,
      "ERROR: NEED AT LEAST 15 SPACE OBJECT INSTANCES"
    );

    return;
  }

  state.level=level;
  state.groups=groups;
  state.column=0;

  state.orbitIndex=-1;
  state.orbitAngle=Math.PI;

  state.dragging=false;
  state.vx=0;
  state.vy=0;
  state.flightTime=0;

  state.safeX=START_X;
  state.safeY=START_Y;

  if (hero) {
    put(hero,START_X,START_Y);

    hero.setAngle(0);
    hero.setOpacity(255);

    show(hero,true);
  }

  if (earth) {
    put(earth,EARTH_X,EARTH_Y);
    show(earth,true);
  }

  [
    rocket,explosion,start,
    retry,arrow,fade
  ].forEach(o=>show(o,false));

  show(status,true);

  clearGlow();

  state.camX=1900;
  state.camY=WORLD_Y;
  state.camZoom=MEMORY_ZOOM;

  camera(
    state.camX,
    state.camY,
    state.camZoom
  );

  say(
    status,
    "LEVEL "+level+
    " - "+levels[level-1].name
  );

  changePhase("intro");
}

// =====================================
// 9. ORBIT
// =====================================

function orbit() {
  if (
    !hero ||
    state.orbitIndex<0
  ) return;

  const body=bodies[state.orbitIndex];
  if (!body) return;

  const c=pos(body);

  const bodyRadius=Math.max(
    body.getWidth(),
    body.getHeight()
  )/2;

  const heroRadius=Math.max(
    hero.getWidth(),
    hero.getHeight()
  )/2;

  const radius=
    bodyRadius+heroRadius+20;

  put(
    hero,
    c.x+Math.cos(state.orbitAngle)*radius,
    c.y+Math.sin(state.orbitAngle)*radius
  );

  hero.setAngle(
    state.orbitAngle*180/Math.PI+90
  );
}

// =====================================
// 10. FAILURE
// =====================================

function lose(index) {
  clearGlow();

  changePhase("lost");

  show(hero,false);
  show(arrow,false);
  show(retry,true);

  say(status,"WRONG OBJECT!");
  say(retry,"TRY AGAIN");

  const target=index<0
    ?earth
    :bodies[index];

  if (explosion&&target) {
    const c=pos(target);

    put(explosion,c.x,c.y);

    if (explosion.setAnimationFrame) {
      explosion.setAnimationFrame(0);
    }

    show(explosion,true);
  }
}

// =====================================
// 11. LEVEL COMPLETION
// =====================================

function complete() {
  clearGlow();

  show(arrow,false);
  show(retry,true);

  if (state.level<3) {
    changePhase("complete");

    say(status,"LEVEL COMPLETE!");
    say(retry,"NEXT LEVEL");
  } else {
    changePhase("won");

    say(status,"YOU REACHED EARTH!");
    say(retry,"PLAY AGAIN");
  }
}

// =====================================
// 12. ROCKET INTRO
// =====================================

if (state.phase==="menu") {
  show(rocket,true);
  show(start,true);

  if (pressed) {
    show(start,false);
    changePhase("shake");
  }
}

else if (state.phase==="shake") {
  if (rocket) {
    rocket.setX(
      state.rocketX+
      Math.sin(state.time*40)*8
    );

    rocket.setY(
      state.rocketY+
      Math.cos(state.time*35)*6
    );

    rocket.setAngle(
      Math.sin(state.time*25)*10
    );
  }

  if (state.time>1.5) {
    if (explosion&&rocket) {
      put(explosion,
        pos(rocket).x,
        pos(rocket).y
      );

      if (explosion.setAnimationFrame) {
        explosion.setAnimationFrame(0);
      }

      show(explosion,true);
    }

    show(rocket,false);
    changePhase("explosion");
  }
}

else if (state.phase==="explosion") {
  if (state.time>0.7) {
    if (hero) {
      put(
        hero,
        state.openingX,
        state.openingY
      );

      show(hero,true);
    }

    changePhase("escape");
  }
}

else if (state.phase==="escape") {
  show(explosion,false);

  if (hero) {
    hero.setX(
      hero.getX()+150*dt
    );

    hero.setY(
      hero.getY()-90*dt
    );

    hero.setAngle(
      hero.getAngle()+200*dt
    );
  }

  if (state.time>1.5) {
    show(hero,false);
    show(fade,true);

    changePhase("blackout");
  }
}

else if (state.phase==="blackout") {
  if (state.time>0.6) {
    show(fade,false);
    startLevel(1);
  }
}

// =====================================
// 13. MEMORY SEQUENCE
// =====================================

else if (state.phase==="intro") {
  clearGlow();

  say(
    status,
    "MEMORISE THE GLOWING OBJECTS!"
  );

  if (state.time>1.5) {
    changePhase("memory");
  }
}

else if (state.phase==="memory") {
  const duration=
    levels[state.level-1].seconds;

  const index=Math.floor(
    state.time/duration
  );

  if (index<5) {
    memoryGlow(
      state.groups[index].correct,
      state.time
    );

    say(
      status,
      "MEMORISE "+(index+1)+" / 5"
    );
  } else {
    clearGlow();

    say(
      status,
      "MEMORY COMPLETE!"
    );

    changePhase("ready");
  }
}

// =====================================
// 14. READY
// =====================================

else if (state.phase==="ready") {
  clearGlow();

  if (state.time>1.2) {
    changePhase("aim");

    say(
      status,
      "DRAG BACK AND RELEASE!"
    );
  }
}

// =====================================
// 15. AIMING
// =====================================

else if (state.phase==="aim") {
  clearGlow();
  show(hero,true);

  if (
    state.orbitIndex>=0 &&
    !state.dragging
  ) {
    state.orbitAngle+=0.5*dt;
    orbit();
  }

  if (hero) {
    const c=pos(hero);

    if (pressed) {
      state.dragging=true;
    }

    let dx=1;
    let dy=0;
    let power=0;

    if (state.dragging) {
      const rawX=c.x-mouse.x;
      const rawY=c.y-mouse.y;

      const length=Math.hypot(
        rawX,rawY
      );

      power=clamp(length,0,500);

      if (length>1) {
        dx=rawX/length;
        dy=rawY/length;
      }

      say(
        status,
        "POWER "+Math.round(power)
      );
    } else {
      say(
        status,
        "COLUMN "+(state.column+1)+
        " - DRAG BACK TO LAUNCH"
      );
    }

    // Arrow keeps Scene Editor size.

    if (arrow) {
      show(arrow,true);
      arrow.setOpacity(255);

      arrow.setAngle(
        Math.atan2(dy,dx)*
        180/Math.PI
      );

      const offset=
        Math.max(
          hero.getWidth(),
          hero.getHeight()
        )/2+
        arrow.getWidth()/2+20;

      put(
        arrow,
        c.x+dx*offset,
        c.y+dy*offset
      );

      if (arrow.setZOrder) {
        arrow.setZOrder(100);
      }
    }

    if (
      state.dragging &&
      released
    ) {
      state.dragging=false;
      show(arrow,false);

      if (power>20) {
        const speed=clamp(
          power*7,
          700,
          2700
        );

        state.vx=dx*speed;
        state.vy=dy*speed;
        state.flightTime=0;

        state.safeX=c.x;
        state.safeY=c.y;

        changePhase("flying");

        say(
          status,
          "REACH THE CORRECT OBJECT!"
        );
      }
    }
  }
}

// =====================================
// 16. FLIGHT AND COLLISIONS
// =====================================

else if (state.phase==="flying") {
  show(arrow,false);

  state.flightTime+=dt;

  if (hero) {
    const before=pos(hero);

    hero.setX(
      hero.getX()+state.vx*dt
    );

    hero.setY(
      hero.getY()+state.vy*dt
    );

    hero.setAngle(
      hero.getAngle()+180*dt
    );

    const after=pos(hero);

    const dx=after.x-before.x;
    const dy=after.y-before.y;

    const lengthSquared=
      dx*dx+dy*dy;

    function collision(obj) {
      if (!obj) return false;

      const c=pos(obj);

      const radius=Math.max(
        obj.getWidth(),
        obj.getHeight()
      )/2+25;

      const t=lengthSquared>0
        ?clamp(
          ((c.x-before.x)*dx+
           (c.y-before.y)*dy)/
          lengthSquared,
          0,1
        )
        :0;

      const nearest={
        x:before.x+dx*t,
        y:before.y+dy*t
      };

      return distance(
        nearest,c
      )<=radius;
    }

    if (
      state.flightTime>0.12 &&
      state.column<5
    ) {
      const group=
        state.groups[state.column];

      let hit=-1;

      for (const index of group.items) {
        if (collision(bodies[index])) {
          hit=index;
          break;
        }
      }

      if (hit>=0) {
        if (hit===group.correct) {
          state.orbitIndex=hit;
          state.column++;

          const c=pos(bodies[hit]);

          state.orbitAngle=
            Math.atan2(
              after.y-c.y,
              after.x-c.x
            );

          changePhase("aim");

          say(
            status,
            state.column===5
              ?"ALL FIVE CORRECT! REACH EARTH!"
              :"CORRECT! NEXT COLUMN!"
          );
        } else {
          lose(hit);
        }
      }
    }

    if (
      state.phase==="flying" &&
      state.column===5 &&
      collision(earth)
    ) {
      complete();
    }

    if (
      state.phase==="flying" &&
      (
        state.flightTime>3.5 ||
        after.y < -500 ||
        after.y > 2000
      )
    ) {
      put(
        hero,
        state.safeX,
        state.safeY
      );

      changePhase("aim");

      say(
        status,
        "MISSED! TRY AGAIN!"
      );
    }
  }
}

// =====================================
// 17. RETRY
// =====================================

else if (
  state.phase==="lost" ||
  state.phase==="complete" ||
  state.phase==="won"
) {
  if (pressed) {
    if (state.phase==="complete") {
      startLevel(state.level+1);
    } else if (state.phase==="won") {
      startLevel(1);
    } else {
      startLevel(state.level);
    }
  }
}

// =====================================
// 18. CAMERA
// =====================================

const openingPhases=[
  "menu",
  "shake",
  "explosion",
  "escape",
  "blackout"
];

if (openingPhases.includes(state.phase)) {
  state.camX=state.openingX;
  state.camY=state.openingY;
  state.camZoom=1;
}

else if (
  state.phase==="intro" ||
  state.phase==="memory"
) {
  state.camX=1900;
  state.camY=WORLD_Y;
  state.camZoom=MEMORY_ZOOM;
}

else {
  const smooth=Math.min(
    1,dt*5
  );

  let targetX=600;

  if (hero) {
    const c=pos(hero);

    const visibleWidth=
      W/Math.max(GAME_ZOOM,0.01);

    targetX=
      c.x+visibleWidth*0.3;
  }

  targetX=clamp(
    targetX,
    600,
    3500
  );

  state.camX+=
    (targetX-state.camX)*smooth;

  state.camY+=
    (WORLD_Y-state.camY)*smooth;

  state.camZoom+=
    (GAME_ZOOM-state.camZoom)*smooth;
}

camera(
  state.camX,
  state.camY,
  state.camZoom
);

// Keep UI fixed on screen.
ui.setCameraX(W/2);
ui.setCameraY(H/2);
ui.setCameraZoom(1);

// Keep transition fixed.
transition.setCameraX(W/2);
transition.setCameraY(H/2);
transition.setCameraZoom(1);

// =====================================
// 19. SAVE STATE
// =====================================

state.previousDown=down;

variable.setString(
  JSON.stringify(state)
);

};
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.Untitled_32sceneCode.userFunc0x939de0(runtimeScene);

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDRocketObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRocketObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStartButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStartButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDExplosionObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDExplosionObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAstronautObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAstronautObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanetObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanetObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet7Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet8Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet8Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet9Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet9Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet10Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet10Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDEarthObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDEarthObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAimArrowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAimArrowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRetryButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRetryButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStatusTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStatusTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFadeOverlayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFadeOverlayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroidObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroidObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDStarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStar2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDStar2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDStar3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDStar3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDStar4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDStar4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDStar5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDStar5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
gdjs.Untitled_32sceneCode.GDRocketObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRocketObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStartButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStartButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDExplosionObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDExplosionObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAstronautObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAstronautObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanetObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanetObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet7Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet8Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet8Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet9Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet9Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet10Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlanet10Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDEarthObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDEarthObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAimArrowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAimArrowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRetryButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRetryButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStatusTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStatusTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFadeOverlayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFadeOverlayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroidObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroidObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDAsteroid5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDStarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStar2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDStar2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDStar3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDStar3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDStar4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDStar4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDStar5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDStar5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
